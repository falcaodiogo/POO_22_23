public interface OrderCostCalculator {
    double calculateOrderCost(Order order);
}
