public enum Type {

    GarageStorage, WarehouseStorage, LockerStorage;
    
}
