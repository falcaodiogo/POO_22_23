
public enum ClientType {
    PERSONAL, ENTERPRISE

}
